# Mind Map Creator & Editor

An interactive Streamlit app for building, editing, saving, and loading mind maps.
Nodes are draggable, color-coded, and organized in a parent-child tree structure.

## Features
- Add nodes attached to any existing parent node
- Rename or delete nodes (deleting cascades to child branches)
- Interactive, physics-based, draggable graph view (via `streamlit-agraph`)
- Save your mind map as JSON and reload it later
- Reset to a blank map at any time

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local URL Streamlit prints (usually `http://localhost:8501`).

## Usage

1. The app starts with a single "Central Idea" root node.
2. Use the sidebar **Add Node** section to branch off new ideas from any existing node.
3. Drag nodes around in the graph to organize them visually.
4. Use **Rename Node** / **Delete Node** to edit the structure.
5. Click **Download mind map (.json)** to save your work.
6. Use **Load mind map (.json)** to resume an earlier session.

## Possible extensions
- Export the rendered graph as a PNG/SVG image
- Add node notes/descriptions shown on hover or click
- Support multiple root nodes (a forest of mind maps)
- Add collapsible branches for large maps
