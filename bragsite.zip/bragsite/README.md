# bragsite

**Turn your GitHub repos into a brag site in one command.** Stars, forks, top languages and your best projects, as a fast static page you can host free on GitHub Pages. Also writes a Markdown brag document for your resume or performance review.

[![CI](https://github.com/YOUR_GITHUB_USERNAME/bragsite/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_GITHUB_USERNAME/bragsite/actions)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

![screenshot](screenshot.png)

## Quickstart

```bash
pip install git+https://github.com/YOUR_GITHUB_USERNAME/bragsite
bragsite build YOUR_USERNAME --out site --markdown brag.md
open site/index.html
```

No token needed for small accounts. If you hit GitHub's rate limit, set `GITHUB_TOKEN` (any token with no scopes works).

## Features

- Ranks projects by stars, forks, recency, and whether they have a description, topics and a demo link
- Language breakdown, totals, and "active in the last 90 days"
- Skips forks and archived repos by default; `--pin` forces your favourites to the top
- One self-contained HTML file with dark mode, mobile layout and social preview tags
- `bragsite search` finds repos on GitHub from the terminal
- All repo text is HTML-escaped, so nobody can inject scripts through a description

## Commands

```bash
# build
bragsite build USER --top 8 --pin my-best-repo,other-repo --min-stars 1 --title "Jane's work"
# search GitHub (same syntax as the GitHub search box)
bragsite search "topic:llm language:python stars:>500" --limit 10
```

## Auto-updating site on GitHub Pages

1. Create a repo (e.g. `YOUR_USERNAME.github.io`).
2. Copy [`.github/workflows/pages.yml`](.github/workflows/pages.yml) into it.
3. In **Settings > Pages**, set Source to **GitHub Actions**.

Your brag site now rebuilds every Monday and on every push.

## Contributing

```bash
pip install -e ".[dev]" && pytest
```

Ideas: themes, contribution-graph stats, org support, pinned-repos GraphQL import.

## License

MIT
