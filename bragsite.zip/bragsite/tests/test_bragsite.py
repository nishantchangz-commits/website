from datetime import datetime, timezone

from bragsite import cli
from bragsite.github import Repo
from bragsite.render import render_html, render_markdown
from bragsite.stats import compute_stats, select_repos

NOW = datetime(2026, 10, 19, tzinfo=timezone.utc)


def repo(name, stars=0, **kw):
    kw.setdefault("pushed_at", "2026-10-01T00:00:00Z")
    return Repo(name=name, url=f"https://github.com/me/{name}", stars=stars, **kw)


def test_ranking_and_filters():
    repos = [repo("small", 1), repo("big", 50), repo("fork", 999, fork=True), repo("old", 500, archived=True)]
    names = [r.name for r in select_repos(repos, now=NOW)]
    assert names == ["big", "small"]
    assert "fork" in [r.name for r in select_repos(repos, include_forks=True, now=NOW)]


def test_pins_come_first():
    repos = [repo("big", 50), repo("tiny", 0)]
    assert select_repos(repos, pins=["TINY"], now=NOW)[0].name == "tiny"


def test_stats():
    repos = [repo("a", 3, language="Python", forks=1), repo("b", 2, language="Python"), repo("c", 1, language="Go")]
    s = compute_stats(repos, now=NOW)
    assert (s.repos, s.stars, s.forks) == (3, 6, 1)
    assert s.languages[0] == ("Python", 2, 67)
    assert s.most_starred.name == "a"


def test_html_escapes_untrusted_text():
    evil = repo("x", description="<script>alert(1)</script>")
    profile = {"login": "me", "name": "<b>Me</b>", "html_url": "https://github.com/me"}
    html = render_html(profile, compute_stats([evil], NOW), [evil], "t", "tag", 6, "2026-10-19")
    assert "<script>alert" not in html and "&lt;script&gt;" in html and "&lt;b&gt;Me" in html


def test_markdown():
    r = repo("a", 3, language="Python", description="Nice")
    md = render_markdown({"login": "me"}, compute_stats([r], NOW), [r], 6)
    assert "[a](https://github.com/me/a)" in md and "Python" in md


def test_cli_build(tmp_path, monkeypatch):
    profile = {"login": "me", "html_url": "https://github.com/me"}
    monkeypatch.setattr(cli, "fetch_all", lambda u, t: (profile, [repo("a", 5, language="Python")]))
    out, md = tmp_path / "site", tmp_path / "brag.md"
    args = cli.build_parser().parse_args(["build", "me", "--out", str(out), "--markdown", str(md)])
    assert args.func(args) == 0
    assert "a" in (out / "index.html").read_text() and (out / "data.json").exists() and md.exists()
