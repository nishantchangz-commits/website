"""Command line interface."""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.table import Table

from . import __version__
from .github import GitHubError, fetch_all, search_repos
from .render import render_html, render_markdown
from .stats import compute_stats, select_repos

console = Console()


def _build(args: argparse.Namespace) -> int:
    try:
        profile, repos = fetch_all(args.username, args.token)
    except GitHubError as e:
        console.print(f"[red]error:[/red] {e}")
        return 1
    pins = [p.strip() for p in args.pin.split(",")] if args.pin else []
    chosen = select_repos(repos, args.include_forks, args.include_archived, pins)
    if args.min_stars:
        chosen = [r for r in chosen if r.stars >= args.min_stars or r.name.lower() in [p.lower() for p in pins]]
    if not chosen:
        console.print("[yellow]No repositories matched your filters.[/yellow]")
        return 1
    stats = compute_stats(chosen)
    name = profile.get("name") or profile.get("login") or args.username
    title = args.title or f"{name}: projects & brag sheet"
    tagline = args.tagline or f"{stats.repos} projects · {stats.stars} stars · {stats.forks} forks"
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "index.html").write_text(
        render_html(profile, stats, chosen, title, tagline, args.top, generated), encoding="utf-8"
    )
    (out / "data.json").write_text(
        json.dumps({"profile": profile.get("login"), "stats": asdict(stats), "repos": [asdict(r) for r in chosen]}, indent=2),
        encoding="utf-8",
    )
    (out / ".nojekyll").write_text("", encoding="utf-8")
    if args.markdown:
        Path(args.markdown).write_text(render_markdown(profile, stats, chosen, args.top), encoding="utf-8")
        console.print(f"Brag doc: [cyan]{args.markdown}[/cyan]")
    console.print(f"[green]Built[/green] {out / 'index.html'}  ({stats.repos} repos, {stats.stars} stars)")
    return 0


def _search(args: argparse.Namespace) -> int:
    try:
        repos = search_repos(args.query, args.limit, args.token, args.sort)
    except GitHubError as e:
        console.print(f"[red]error:[/red] {e}")
        return 1
    table = Table(title=f"GitHub search: {args.query}")
    for col in ("Repo", "★", "Language", "Description"):
        table.add_column(col, overflow="fold")
    for r in repos:
        table.add_row(f"{r.owner}/{r.name}", str(r.stars), r.language or "", r.description[:80])
    console.print(table)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="bragsite", description="Turn your GitHub repos into a brag site.")
    p.add_argument("--version", action="version", version=f"bragsite {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    b = sub.add_parser("build", help="generate a static brag site for a GitHub user")
    b.add_argument("username")
    b.add_argument("--out", default="site", help="output folder (default: site)")
    b.add_argument("--top", type=int, default=6, help="number of featured projects (default 6)")
    b.add_argument("--pin", help="comma-separated repo names to feature first")
    b.add_argument("--min-stars", type=int, default=0, help="hide repos below this star count")
    b.add_argument("--include-forks", action="store_true")
    b.add_argument("--include-archived", action="store_true")
    b.add_argument("--title")
    b.add_argument("--tagline")
    b.add_argument("--markdown", metavar="FILE", help="also write a Markdown brag document")
    b.add_argument("--token", help="GitHub token (or set GITHUB_TOKEN)")
    b.set_defaults(func=_build)

    s = sub.add_parser("search", help="search GitHub repos, e.g. 'topic:llm language:python'")
    s.add_argument("query")
    s.add_argument("--limit", type=int, default=10)
    s.add_argument("--sort", default="stars", choices=["stars", "forks", "updated"])
    s.add_argument("--token")
    s.set_defaults(func=_search)
    return p


def main(argv=None) -> None:
    args = build_parser().parse_args(argv)
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
