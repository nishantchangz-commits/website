"""HTML and Markdown output."""
from __future__ import annotations

from jinja2 import Environment, select_autoescape

_HTML = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }}</title>
<meta name="description" content="{{ tagline }}">
<meta property="og:title" content="{{ title }}"><meta property="og:description" content="{{ tagline }}">
<style>
:root{--bg:#fafafa;--fg:#1a1a1a;--card:#fff;--line:#e3e3e8;--mute:#666;--acc:#6d4aff}
@media(prefers-color-scheme:dark){:root{--bg:#121216;--fg:#eee;--card:#1c1c22;--line:#2d2d36;--mute:#9a9aa5;--acc:#9b85ff}}
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--fg);line-height:1.5}
main{max-width:980px;margin:0 auto;padding:2.5rem 1.2rem 4rem}a{color:var(--acc);text-decoration:none}a:hover{text-decoration:underline}
header{display:flex;gap:1.4rem;align-items:center;flex-wrap:wrap}
header img{width:110px;height:110px;border-radius:50%;border:3px solid var(--acc)}
h1{margin:0;font-size:2rem}.tag{color:var(--mute);margin:.2rem 0}.links a{margin-right:1rem}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:.9rem;margin:2rem 0}
.stat{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1rem}
.stat b{display:block;font-size:1.8rem}.stat span{color:var(--mute);font-size:.85rem}
h2{margin:2.2rem 0 .8rem}
.bars .row{display:flex;align-items:center;gap:.7rem;margin:.35rem 0}.bars .name{width:110px;font-size:.9rem}
.bars .bar{flex:1;height:10px;background:var(--line);border-radius:99px;overflow:hidden}
.bars .bar i{display:block;height:100%;background:var(--acc)}.bars .pct{width:40px;text-align:right;color:var(--mute);font-size:.85rem}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:1rem}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1.1rem;display:flex;flex-direction:column;gap:.5rem}
.card h3{margin:0;font-size:1.05rem}.card p{margin:0;color:var(--mute);font-size:.92rem;flex:1}
.meta{display:flex;gap:.9rem;font-size:.85rem;color:var(--mute);flex-wrap:wrap}
.topics span{display:inline-block;font-size:.72rem;padding:.1rem .5rem;border-radius:99px;background:var(--line);margin:0 .25rem .25rem 0}
ul.all{list-style:none;padding:0;columns:2 300px;column-gap:2rem}ul.all li{padding:.25rem 0;break-inside:avoid}ul.all small{color:var(--mute)}
footer{margin-top:3rem;color:var(--mute);font-size:.85rem;text-align:center}
</style></head><body><main>
<header>
{% if profile.avatar_url %}<img src="{{ profile.avatar_url }}" alt="{{ profile.login }}">{% endif %}
<div><h1>{{ profile.name or profile.login }}</h1>
{% if profile.bio %}<p class="tag">{{ profile.bio }}</p>{% endif %}
<p class="tag">{{ tagline }}</p>
<div class="links"><a href="{{ profile.html_url }}">GitHub</a>
{% if profile.blog %}<a href="{{ profile.blog if profile.blog.startswith('http') else 'https://' ~ profile.blog }}">Website</a>{% endif %}
{% if profile.twitter_username %}<a href="https://x.com/{{ profile.twitter_username }}">X</a>{% endif %}</div></div>
</header>

<section class="stats">
<div class="stat"><b>{{ stats.repos }}</b><span>public projects</span></div>
<div class="stat"><b>{{ stats.stars }}</b><span>stars earned</span></div>
<div class="stat"><b>{{ stats.forks }}</b><span>forks</span></div>
<div class="stat"><b>{{ stats.active_last_90d }}</b><span>active in last 90 days</span></div>
{% if profile.followers %}<div class="stat"><b>{{ profile.followers }}</b><span>followers</span></div>{% endif %}
</section>

{% if stats.languages %}<h2>Languages</h2><div class="bars">
{% for name, count, pct in stats.languages %}<div class="row"><span class="name">{{ name }}</span><span class="bar"><i style="width:{{ pct }}%"></i></span><span class="pct">{{ pct }}%</span></div>{% endfor %}
</div>{% endif %}

<h2>Featured projects</h2><div class="grid">
{% for r in featured %}<div class="card">
<h3><a href="{{ r.url }}">{{ r.name }}</a></h3>
<p>{{ r.description or 'No description yet.' }}</p>
<div class="topics">{% for t in r.topics[:4] %}<span>{{ t }}</span>{% endfor %}</div>
<div class="meta">{% if r.language %}<span>● {{ r.language }}</span>{% endif %}<span>★ {{ r.stars }}</span><span>⑂ {{ r.forks }}</span>
{% if r.homepage %}<a href="{{ r.homepage }}">demo ↗</a>{% endif %}</div></div>{% endfor %}
</div>

{% if others %}<h2>More</h2><ul class="all">
{% for r in others %}<li><a href="{{ r.url }}">{{ r.name }}</a> <small>{% if r.language %}{{ r.language }} · {% endif %}★ {{ r.stars }}</small></li>{% endfor %}
</ul>{% endif %}

<footer>Generated {{ generated }} with <a href="https://github.com/YOUR_GITHUB_USERNAME/bragsite">bragsite</a></footer>
</main></body></html>"""

_env = Environment(autoescape=select_autoescape(default=True, default_for_string=True))


def render_html(profile: dict, stats, repos: list, title: str, tagline: str, top: int, generated: str) -> str:
    return _env.from_string(_HTML).render(
        profile=profile, stats=stats, featured=repos[:top], others=repos[top:], title=title,
        tagline=tagline, generated=generated,
    )


def render_markdown(profile: dict, stats, repos: list, top: int) -> str:
    name = profile.get("name") or profile.get("login")
    lines = [
        f"# {name}: brag document",
        "",
        f"**{stats.repos}** public projects · **{stats.stars}** stars · **{stats.forks}** forks · "
        f"**{stats.active_last_90d}** active in the last 90 days",
        "",
    ]
    if stats.languages:
        lines += ["**Languages:** " + ", ".join(f"{n} ({p}%)" for n, _, p in stats.languages), ""]
    lines += ["## Top projects", ""]
    for r in repos[:top]:
        extra = f" [{r.language}]" if r.language else ""
        lines.append(f"- **[{r.name}]({r.url})**{extra} ★{r.stars}: {r.description or 'No description'}")
    return "\n".join(lines) + "\n"
