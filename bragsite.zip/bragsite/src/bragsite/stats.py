"""Ranking repos and computing brag stats."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from .github import Repo


def _days_since(iso: str, now: Optional[datetime] = None) -> float:
    if not iso:
        return 10_000.0
    now = now or datetime.now(timezone.utc)
    return (now - datetime.fromisoformat(iso.replace("Z", "+00:00"))).total_seconds() / 86400


def score(repo: Repo, now: Optional[datetime] = None) -> float:
    days = _days_since(repo.pushed_at, now)
    s = repo.stars * 3 + repo.forks * 2
    s += 5 if days < 30 else 2 if days < 180 else 0
    s += 2 if repo.description else 0
    s += 1 if repo.topics else 0
    s += 2 if repo.homepage else 0
    return s


def select_repos(
    repos: list,
    include_forks: bool = False,
    include_archived: bool = False,
    pins: Optional[list] = None,
    now: Optional[datetime] = None,
) -> list:
    """Filter and rank repos. Pinned repos come first, in the order given."""
    pins = [p.lower() for p in (pins or [])]
    kept = [r for r in repos if (include_forks or not r.fork) and (include_archived or not r.archived)]
    pinned = [next(r for r in kept if r.name.lower() == p) for p in pins if any(r.name.lower() == p for r in kept)]
    rest = sorted((r for r in kept if r not in pinned), key=lambda r: score(r, now), reverse=True)
    return pinned + rest


@dataclass
class Stats:
    repos: int
    stars: int
    forks: int
    languages: list  # [(name, count, percent)]
    most_starred: Optional[Repo]
    active_last_90d: int


def compute_stats(repos: list, now: Optional[datetime] = None) -> Stats:
    langs = Counter(r.language for r in repos if r.language)
    total = sum(langs.values()) or 1
    return Stats(
        repos=len(repos),
        stars=sum(r.stars for r in repos),
        forks=sum(r.forks for r in repos),
        languages=[(n, c, round(100 * c / total)) for n, c in langs.most_common(6)],
        most_starred=max(repos, key=lambda r: r.stars, default=None),
        active_last_90d=sum(1 for r in repos if _days_since(r.pushed_at, now) < 90),
    )
