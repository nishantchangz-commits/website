"""Minimal GitHub REST client (users, repos, search)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

import httpx

API = "https://api.github.com"


class GitHubError(RuntimeError):
    pass


@dataclass
class Repo:
    name: str
    url: str
    description: str = ""
    stars: int = 0
    forks: int = 0
    language: Optional[str] = None
    topics: list = field(default_factory=list)
    pushed_at: str = ""
    created_at: str = ""
    homepage: str = ""
    fork: bool = False
    archived: bool = False
    owner: str = ""

    @classmethod
    def from_api(cls, d: dict) -> "Repo":
        return cls(
            name=d.get("name", ""),
            url=d.get("html_url", ""),
            description=d.get("description") or "",
            stars=d.get("stargazers_count", 0),
            forks=d.get("forks_count", 0),
            language=d.get("language"),
            topics=d.get("topics") or [],
            pushed_at=d.get("pushed_at") or "",
            created_at=d.get("created_at") or "",
            homepage=d.get("homepage") or "",
            fork=bool(d.get("fork")),
            archived=bool(d.get("archived")),
            owner=(d.get("owner") or {}).get("login", ""),
        )


def _headers(token: Optional[str]) -> dict:
    h = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    token = token or os.environ.get("GITHUB_TOKEN")
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def _get(client: httpx.Client, url: str, params: Optional[dict] = None):
    r = client.get(url, params=params)
    if r.status_code == 404:
        raise GitHubError("Not found on GitHub (check the username)")
    if r.status_code in (401, 403):
        raise GitHubError(
            f"GitHub refused the request ({r.status_code}). You may be rate limited: "
            "set GITHUB_TOKEN or pass --token to raise the limit."
        )
    r.raise_for_status()
    return r.json()


def fetch_all(username: str, token: Optional[str] = None) -> tuple:
    """Return (profile dict, list[Repo]) for a user, following pagination."""
    with httpx.Client(headers=_headers(token), timeout=30.0) as client:
        profile = _get(client, f"{API}/users/{username}")
        repos, page = [], 1
        while True:
            batch = _get(
                client,
                f"{API}/users/{username}/repos",
                {"per_page": 100, "page": page, "type": "owner", "sort": "pushed"},
            )
            repos += [Repo.from_api(d) for d in batch]
            if len(batch) < 100:
                break
            page += 1
    return profile, repos


def search_repos(query: str, limit: int = 10, token: Optional[str] = None, sort: str = "stars") -> list:
    """Search public repos, e.g. 'topic:llm language:python stars:>100'."""
    with httpx.Client(headers=_headers(token), timeout=30.0) as client:
        data = _get(
            client,
            f"{API}/search/repositories",
            {"q": query, "sort": sort, "order": "desc", "per_page": min(limit, 100)},
        )
    return [Repo.from_api(d) for d in data.get("items", [])][:limit]
